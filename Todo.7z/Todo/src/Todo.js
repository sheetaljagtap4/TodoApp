import React, { Component } from 'react';

export default class Todo extends Component {
    constructor(){
        super();
        this.state={
            text: [{task:"Go to the gym", done: false }],
            checkedElem:[],
            arrayToDisplay: [{task:"Go to the gym", done: false }, ],
        }
        this.display = this.display.bind(this);
        this.setChangedVal = this.setChangedVal.bind(this);
        this.showAll = this.showAll.bind(this);
        this.showActive = this.showActive.bind(this)
        this.showCompleted = this.showCompleted.bind(this)
    }
	render() {
		let idd=0;
		return (
			<div className=" container-fluid well halfwidth">
				 <form onSubmit={this.display} >
					<div className="row">
						<div className="form-group col-md-12">
							<input type="text" className="form-control " id="usr"/>
						</div>
						
						<div className="textCenter col-md-12">
							{
								this.state.arrayToDisplay.map( (rr,index) => 
								<div  className="checkbox checkbox-circle">
								   
										<input  key={index} type="checkbox" onChange={this.setChangedVal} data-id={idd++}  checked={rr.done}/>
										<label> 
										<div className="">   {rr.task} </div>
										</label>
									
								</div>)
							}
						</div>
					   
						<footer>
							<div className="col-md-2">
									item left    
							 </div>
							 <div>
								<ul className="list-inline col-md-6">
										<li><a href="" onClick={this.showAll}>All</a></li>
									<li><a href="" onClick={this.showActive}>Active</a></li>
									<li><a href="" onClick={this.showCompleted}>Completed</a></li>
								</ul>   
							</div>
							<div className="fright col-md-4">
								 <a href=""> Clear completed</a>
							</div>
						</footer>
					</div>
				</form>
			</div>
		)
	}

	display(event){
		event.preventDefault();
		var a1 = event.target.querySelectorAll('[data-id]');
		var length = a1.length;  
        this.setState({
            text: this.state.text.concat({task: document.getElementById('usr').value, done:false, id: Number( a1[length-1].getAttribute('data-id'))+1 }),
        })    
        setTimeout(()=>{
            var clonedArray = [...this.state.text];
		   this.setState({
			 arrayToDisplay: clonedArray,
		   })
        },100)
        event.target.querySelector('input').value='';       
    }

    storeElements(e){
        if(e.target.checked === true){
           this.setState({
               checkedElem: this.state.checkedElem.concat(e.target.innerHTML)
           }) 
        }   
    }
    
    setChangedVal(e){
        const text = [ ...this.state.text ];
        let xx = Number(e.target.getAttribute('data-id'));
		for(var i=0; i<text.length;i++){
			if(text[i].id === xx){
					text[i].done = true;
			}
		}

		this.setState({
			text: text,
		})   
	}  
		
    showAll(e){
        e.preventDefault();
        const text = [ ...this.state.text ];
        this.setState({
                arrayToDisplay: text,
            })
    }

    showActive(e){
        e.preventDefault();
        const text = [ ...this.state.text ];
        var newarray = text.filter( (cc) =>  cc.done === false);
        this.setState({
            arrayToDisplay: newarray,
        })

    }

    showCompleted(e){
        e.preventDefault();
        const text = [ ...this.state.text ];
        var newarray = text.filter( (cc) =>  cc.done === true);
        this.setState({
            arrayToDisplay: newarray,
        })
    }
}

