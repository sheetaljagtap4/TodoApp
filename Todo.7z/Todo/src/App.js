import React, { Component } from 'react';
import Todo from "./Todo"

import './App.css';

class App extends Component {
  render() {
    
    return (
      <div className="App">
        <header >
          
          <h1 className="App-title">Welcome </h1>
          
         
            <Todo/>
           
        </header>
        
      </div>
    );
  }
}

export default App;
